# Widget_Discord_NeoFrag
Widget d'affichage du serveur Discord pour NeoFrag

// UTILISATION DU WIDGET

1. Rendez-vous sur le site https://discordapp.com/
	
2. Créez votre serveur Discord
	
3. Rendez-vous dans les paramètres du serveur créé,
dans l'onglet "Widget" et cochez la case "Activer le widget"
	
4. Récupérez "l'identifiant du serveur (ID)"
	
5. Lancez le LiveEditor NeoFrag et ajoutez le widget 	"Discord".
Dans les options, renseignez:
	- L'identifiant du serveur.
	- L'identifiant d'invitation (ex: Https://discord.gg/AeBjA).
	- Le thème de couleur.
	- La hauteur du Widget
	
Validez.

// SUPPORT & AIDES
	
Pour toutes vos demandes d'aides, merci de nous rendre visite sur le forum à l'adresse suivante : http://www.neofrag.fr/forum.html
	
Exposez nous votre problème/question et nous ferons notre possible pour vous répondre rapidement.
	

// CHANGELOG

27/04/2017 - 1ère diffusion du widget (compatible 1.6)
	
29/04/2017 - Amélioration du Design et ajout du bouton de connexion

08/05/2017 - Ajout du réglage de la hauteur et modification de la barre de défillement vertical
